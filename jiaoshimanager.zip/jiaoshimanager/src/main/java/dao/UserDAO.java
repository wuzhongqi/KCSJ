package dao;

import manager.baseDao.BaseHibernateDao;
import manager.entity.User;


public interface UserDAO extends  BaseHibernateDao<User> {

}
