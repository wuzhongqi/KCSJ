package dao;

public interface ClassroomDAO {

}
